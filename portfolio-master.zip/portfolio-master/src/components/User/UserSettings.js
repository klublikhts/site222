import React from "react";
import PasswordlessLogin from "./Settings/PasswordlessLogin";

const UserSettings = () => {
	return (
		<>
			<PasswordlessLogin/>
		</>
	);
};

export default UserSettings;
